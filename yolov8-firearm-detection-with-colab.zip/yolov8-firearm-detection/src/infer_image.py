"""Single image inference and save visualization
Usage:
  python src/infer_image.py --img ../data/sample/image1.jpg --weights ../runs/train/.../best.pt
"""
import argparse
import cv2
from ultralytics import YOLO
from utils import draw_boxes

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--img", required=True)
    p.add_argument("--weights", required=True)
    p.add_argument("--conf", type=float, default=0.35)
    return p.parse_args()

def main():
    args = parse_args()
    img = cv2.imread(args.img)
    model = YOLO(args.weights)
    results = model.predict(source=img, conf=args.conf, verbose=False)
    boxes = []
    for r in results:
        for box in r.boxes:
            xyxy = box.xyxy[0].cpu().numpy().astype(int).tolist()
            conf = float(box.conf[0].cpu().numpy())
            cls = int(box.cls[0].cpu().numpy())
            boxes.append((xyxy, conf, cls))
        break
    out = draw_boxes(img, boxes, class_names=['firearm'])
    out_path = args.img.replace(".jpg", "_pred.jpg")
    cv2.imwrite(out_path, out)
    print("Saved:", out_path)

if __name__ == "__main__":
    main()
