# YOLOv8 Firearm Detection (real-time)

## Overview
This repo implements a YOLOv8-based firearm detection system for real-time surveillance (webcam / RTSP).
It includes training scripts, real-time inference, export to ONNX/TorchScript and evaluation.

## Contents
- `src/` : training/inference/export/eval scripts
- `data.yaml` : dataset config (edit for your paths)
- `requirements.txt`
- `.github/workflows/python-ci.yml` : minimal CI smoke test

## Notes about archive format
You asked for a RAR archive. This environment cannot create .rar files (rar executable not available).
Instead this package includes a ready-to-upload **ZIP** archive `yolov8-firearm-detection.zip`.
GitHub accepts zip/tar archives for uploads. If you *must* have a .rar file, create it locally:

Windows (with WinRAR installed):
1. Right-click the extracted folder -> Add to archive... -> select RAR.

Linux (with rar):
rar a yolov8-firearm-detection.rar yolov8-firearm-detection/

## Quickstart
1. Create a virtualenv: `python -m venv .venv && source .venv/bin/activate`
2. Install: `pip install -r requirements.txt`
3. Edit `data.yaml` to point to your dataset.
4. Train: `python src/train.py --data data.yaml --model yolov8n.pt --epochs 50 --batch 16`
5. Real-time inference: `python src/infer_realtime.py --source 0 --weights runs/train/yolov8-firearm/weights/best.pt`

## Ethics & Legal
Use responsibly and comply with local privacy and surveillance laws. See full README in repo for more guidance.


## Colab Notebook
- `notebooks/Train_YOLOv8_Firearm.ipynb` — open in Google Colab and follow the cells to train/validate/export quickly.
