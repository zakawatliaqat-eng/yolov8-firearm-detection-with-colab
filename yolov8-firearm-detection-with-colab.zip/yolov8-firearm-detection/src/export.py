"""Export YOLOv8 weights to ONNX or TorchScript
Usage:
  python src/export.py --weights ../runs/train/.../best.pt --format onnx
"""
import argparse
from ultralytics import YOLO

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--weights", required=True)
    p.add_argument("--format", choices=['onnx', 'torchscript'], default='onnx')
    p.add_argument("--imgsz", type=int, default=640)
    return p.parse_args()

def main():
    args = parse_args()
    model = YOLO(args.weights)
    if args.format == 'onnx':
        model.export(format='onnx', imgsz=args.imgsz)
        print("Exported ONNX.")
    else:
        model.export(format='torchscript', imgsz=args.imgsz)
        print("Exported TorchScript.")

if __name__ == "__main__":
    main()
