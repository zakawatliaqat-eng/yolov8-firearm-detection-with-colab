"""Real-time inference: webcam / RTSP / video file
Usage:
  python src/infer_realtime.py --source 0 --weights ../runs/train/yolov8-firearm/weights/best.pt
"""
import argparse, time
import cv2
from ultralytics import YOLO
from utils import draw_boxes

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--source", type=str, default="0", help="0 for webcam, or path/rtsp url")
    p.add_argument("--weights", type=str, required=True, help="path to weights .pt")
    p.add_argument("--conf", type=float, default=0.35, help="confidence threshold")
    p.add_argument("--device", type=str, default="0", help="cuda device or cpu")
    return p.parse_args()

def main():
    args = parse_args()
    src = int(args.source) if args.source.isdigit() else args.source
    cap = cv2.VideoCapture(src)
    model = YOLO(args.weights)
    try:
        model.fuse()
    except Exception:
        pass

    prev_time = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        results = model.predict(source=frame, conf=args.conf, verbose=False)
        boxes = []
        for r in results:
            for box in r.boxes:
                xyxy = box.xyxy[0].cpu().numpy().astype(int).tolist()
                conf = float(box.conf[0].cpu().numpy())
                cls = int(box.cls[0].cpu().numpy())
                boxes.append((xyxy, conf, cls))
            break
        frame = draw_boxes(frame, boxes, class_names=['firearm'])
        curr_time = time.time()
        fps = 1 / (curr_time - prev_time) if prev_time else 0
        prev_time = curr_time
        cv2.putText(frame, f"FPS: {fps:.1f}", (10,30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)
        cv2.imshow("Firearm Detection", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
