"""Train script using ultralytics YOLOv8 API.
Usage:
  python src/train.py --data ../data.yaml --model yolov8n.pt --epochs 50 --batch 16
"""
import argparse
from ultralytics import YOLO
import os

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data", type=str, default="../data.yaml", help="path to data.yaml")
    p.add_argument("--model", type=str, default="yolov8n.pt", help="pretrained model or .yaml")
    p.add_argument("--epochs", type=int, default=50)
    p.add_argument("--batch", type=int, default=16)
    p.add_argument("--imgsz", type=int, default=640)
    p.add_argument("--project", type=str, default="../runs/train")
    p.add_argument("--name", type=str, default="yolov8-firearm")
    return p.parse_args()

def main():
    args = parse_args()
    os.makedirs(args.project, exist_ok=True)
    model = YOLO(args.model)  # load model (weights or yaml)
    model.train(data=args.data,
                epochs=args.epochs,
                batch=args.batch,
                imgsz=args.imgsz,
                project=args.project,
                name=args.name,
                workers=8,
                device=0)  # use GPU 0; set to 'cpu' or other device as needed

if __name__ == "__main__":
    main()
