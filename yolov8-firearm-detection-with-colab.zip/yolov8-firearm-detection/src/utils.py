import cv2

def draw_boxes(img, boxes, class_names=None):
    """
    boxes: list of tuples ( [x1,y1,x2,y2], conf, cls )
    """
    out = img.copy()
    for (xyxy, conf, cls) in boxes:
        x1,y1,x2,y2 = xyxy
        label = f"{class_names[cls] if class_names else cls}: {conf:.2f}"
        cv2.rectangle(out, (x1,y1), (x2,y2), (0,0,255), 2)
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 1)
        cv2.rectangle(out, (x1, y1 - th - 6), (x1 + tw, y1), (0,0,255), -1)
        cv2.putText(out, label, (x1, y1 - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 1)
    return out
