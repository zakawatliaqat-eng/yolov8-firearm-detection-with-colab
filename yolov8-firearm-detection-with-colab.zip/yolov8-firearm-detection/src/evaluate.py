"""Evaluate model on validation set
python src/evaluate.py --weights ../runs/train/.../best.pt --data ../data.yaml
"""
import argparse
from ultralytics import YOLO

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--weights", required=True)
    p.add_argument("--data", required=True)
    return p.parse_args()

def main():
    args = parse_args()
    model = YOLO(args.weights)
    metrics = model.val(data=args.data, imgsz=640)
    print(metrics)

if __name__ == "__main__":
    main()
